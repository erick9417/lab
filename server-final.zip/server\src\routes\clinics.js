import { Router } from 'express'
import pool from '../db.js'

const router = Router()

// Crear/actualizar clínica
router.post('/', async (req, res) => {
  const { id, name, phone, email, address } = req.body
  if (!name) return res.status(400).json({ error: 'Nombre de clínica es obligatorio' })
  try {
    if (id) {
      await pool.query(
        'UPDATE clinics SET name=?, phone=?, email=?, address=? WHERE id=?',
        [name, phone || null, email || null, address || null, id]
      )
      return res.json({ id, name, phone, email, address })
    } else {
      const [result] = await pool.query(
        'INSERT INTO clinics (name, phone, email, address) VALUES (?, ?, ?, ?)',
        [name, phone || null, email || null, address || null]
      )
      return res.status(201).json({ id: result.insertId, name, phone, email, address })
    }
  } catch (e) {
    console.error(e)
    res.status(500).json({ error: 'Error al guardar clínica' })
  }
})

export default router
