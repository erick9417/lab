import { Router } from 'express'
import bcrypt from 'bcryptjs'
import pool from '../db.js'

const router = Router()

// Crear usuario (solo Admin)
router.post('/', async (req, res) => {
  const { email, password, role, clinicId } = req.body
  if (!email || !password || !role) return res.status(400).json({ error: 'Campos obligatorios: email, password, role' })
  try {
    const password_hash = await bcrypt.hash(password, 10)
    const [result] = await pool.query(
      'INSERT INTO users (email, password_hash, role, clinic_id) VALUES (?, ?, ?, ?)',
      [email, password_hash, role, clinicId || null]
    )
    res.status(201).json({ id: result.insertId, email, role, clinicId: clinicId || null })
  } catch (e) {
    console.error(e)
    res.status(500).json({ error: 'Error al crear usuario' })
  }
})

export default router
