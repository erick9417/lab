import dotenv from 'dotenv'
import bcrypt from 'bcryptjs'
import pool from './db.js'

dotenv.config()

async function run() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      email VARCHAR(255) UNIQUE NOT NULL,
      password_hash VARCHAR(255) NOT NULL,
      role ENUM('admin','clinic','workshop') NOT NULL,
      clinic_id INT NULL
    );
  `)

  await pool.query(`
    CREATE TABLE IF NOT EXISTS clinics (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      phone VARCHAR(50),
      email VARCHAR(255),
      address VARCHAR(255)
    );
  `)

  await pool.query(`
    CREATE TABLE IF NOT EXISTS requests (
      id INT AUTO_INCREMENT PRIMARY KEY,
      patient_id INT NOT NULL,
      doctor_name VARCHAR(255) NOT NULL,
      template_type VARCHAR(255) NOT NULL,
      foot_side ENUM('Izquierdo','Derecho','Ambos') NOT NULL,
      shoe_size VARCHAR(50) NOT NULL,
      conditions_json TEXT,
      observations TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
  `)

  const [rows] = await pool.query('SELECT id FROM users WHERE email=?', ['admin@lucvanlatam.com'])
  if (rows.length === 0) {
    const hash = await bcrypt.hash('$Lucv@n123', 10)
    await pool.query(
      'INSERT INTO users (email, password_hash, role) VALUES (?, ?, ?)',
      ['admin@lucvanlatam.com', hash, 'admin']
    )
    console.log('Usuario admin creado')
  } else {
    console.log('Usuario admin ya existe')
  }

  process.exit(0)
}

run().catch(err => { console.error(err); process.exit(1) })
