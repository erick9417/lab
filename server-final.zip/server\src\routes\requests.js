import { Router } from 'express'
import pool from '../db.js'

const router = Router()

// Crear solicitud de plantilla
router.post('/', async (req, res) => {
  const { patientId, doctorName, templateType, footSide, shoeSize, conditions, observations } = req.body
  if (!patientId || !doctorName || !templateType || !footSide || !shoeSize) {
    return res.status(400).json({ error: 'Campos obligatorios: patientId, doctorName, templateType, footSide, shoeSize' })
  }
  try {
    const [result] = await pool.query(
      'INSERT INTO requests (patient_id, doctor_name, template_type, foot_side, shoe_size, conditions_json, observations) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [patientId, doctorName, templateType, footSide, shoeSize, JSON.stringify(conditions || {}), observations || null]
    )
    res.status(201).json({ id: result.insertId })
  } catch (e) {
    console.error(e)
    res.status(500).json({ error: 'Error al crear solicitud' })
  }
})

export default router
