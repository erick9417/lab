import { Router } from 'express'
import jwt from 'jsonwebtoken'
import bcrypt from 'bcryptjs'
import pool from '../db.js'

const router = Router()

router.post('/login', async (req, res) => {
  const { email, password } = req.body
  if (!email || !password) return res.status(400).json({ error: 'Credenciales incompletas' })
  try {
    const [rows] = await pool.query('SELECT id, email, password_hash, role FROM users WHERE email = ?', [email])
    const user = rows[0]
    if (!user) return res.status(401).json({ error: 'Usuario o contraseña inválidos' })
    const ok = await bcrypt.compare(password, user.password_hash)
    if (!ok) return res.status(401).json({ error: 'Usuario o contraseña inválidos' })
    const token = jwt.sign({ uid: user.id, role: user.role }, process.env.JWT_SECRET || 'secret', { expiresIn: '7d' })
    res.json({ token, user: { id: user.id, email: user.email, role: user.role } })
  } catch (e) {
    console.error(e)
    res.status(500).json({ error: 'Error en el servidor' })
  }
})

export default router
